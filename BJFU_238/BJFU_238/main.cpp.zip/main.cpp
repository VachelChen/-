#include<iostream>
using namespace std;
 
//点为2表示迷宫图为"█"，点为0表示迷宫图为" "
int migo[9][9]=
{
  {2, 2, 2, 2, 2, 2, 2, 2, 2},
  {2, 0, 0, 0, 0, 0, 0, 0, 2},
  {2, 0, 2, 2, 0, 2, 2, 0, 2},
  {2, 0, 2, 0, 0, 2, 0, 0, 2},
  {2, 0, 2, 0, 2, 0, 2, 0, 2},
  {2, 0, 0, 0, 0, 0, 2, 0, 2},
  {2, 2, 0, 2, 2, 0, 2, 0, 2},
  {2, 0, 0, 0, 0, 0, 0, 0, 2},
  {2, 2, 2, 2, 2, 2, 2, 2, 2}
};
//迷宫图
 
int starti=1,startj=1;//出发点
int endi=7,endj=7;//出口
 
/*******
递归算法：
  算法中，if语句即为递归函数的出口，当到达迷宫出口时，输出；
  若未到达迷宫出口，并且存在可走路径即迷宫中为" "时，依次进行
  各个方向上的探索，直到找到将所有可能的结果试探完为止。
*******/
void visit(int i,int j)
{
  int m,n;
  migo[i][j]=1;  //当值为1表示此点可以走
  if(i==endi&&j==endj)//判断有没有到到达迷宫出口
  {
    cout<<endl;
    for(m=0; m<9; m++)
    {
      for(n=0; n<9; n++)
      {
        if(migo[m][n]==2)  //如果为值为2，表示迷宫中为"█"
          cout<<"█";
        else if(migo[m][n]==1)
          cout<<"->";
        else if(migo[m][n]==2)
          cout<<"↓";
        else if(migo[m][n]==3)
          cout<<"←";
        else if(migo[m][n]==4)
          cout<<"↑";
        else
          cout<<" ";
      }
      cout<<endl;
    }
  }
  if(migo[i][j+1]==0)
    visit(i,j+1);//四种走法，右，下，左，上
  if(migo[i+1][j]==0)
    visit(i+1,j);
  if(migo[i][j-1]==0)
    visit(i,j-1);
  if(migo[i-1][j]==0)
    visit(i-1,j);
  migo[i][j]=0;
}
 
/********
main函数：
首先显示给出的迷宫图，然后调用visit函数，对迷宫进行探索
********/
int main()
{
  int i,j;
  cout<<"显示迷宫："<<endl;
  for(i=0; i<9; i++)
  {
    for(j=0; j<9; j++)
      if(migo[i][j]==2)
        cout<<"█";
      else
        cout<<" ";
    cout<<endl;
  }
  cout<<"迷宫路径如下：";
  visit(starti,startj);
  return 0;
}
